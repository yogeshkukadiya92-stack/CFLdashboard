import { NextRequest, NextResponse } from "next/server";
import { companyApiError, requireCompany } from "@/lib/company-api";
import { companyCallReport } from "@/lib/company-call-report";
import { callRecordsCsv } from "@/lib/call-analytics";

export async function GET(request: NextRequest) {
  const auth = await requireCompany(request, false, true);
  if (auth.response) return auth.response;
  try {
    const records = await companyCallReport(auth.session!, request.nextUrl.searchParams);
    return new NextResponse(`\uFEFF${callRecordsCsv(records)}`, { headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": 'attachment; filename="call-report.csv"',
      "Cache-Control": "private, no-store",
    } });
  } catch (error) { return companyApiError(error); }
}
