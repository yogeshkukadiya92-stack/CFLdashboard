import "server-only";
import type { CompanySession } from "./company-auth.ts";
import { normalizeAnalyticsFilters } from "./company-analytics.ts";
import { withTenantTransaction } from "./platform/database.ts";
import type { CallFlowCallRecord } from "./callflow-connector.ts";

export async function companyCallReport(session: CompanySession, search: URLSearchParams) {
  const filters = normalizeAnalyticsFilters(search);
  return withTenantTransaction(session.tenantId, async (client) => {
    const values: unknown[] = [session.tenantId, filters.from, filters.to];
    const clauses = ["calls.tenant_id=$1",
      "calls.started_at >= ($2::date::timestamp AT TIME ZONE 'Asia/Kolkata')",
      "calls.started_at < (($3::date+1)::timestamp AT TIME ZONE 'Asia/Kolkata')"];
    if (filters.owner) { values.push(filters.owner); clauses.push(`calls.salesperson_membership_id=$${values.length}::uuid`); }
    if (filters.source) { values.push(filters.source); clauses.push(`COALESCE(lead.source,'unknown')=$${values.length}`); }
    const result = await client.query(`SELECT calls.id,calls.event_key AS "eventUuid",calls.lead_id AS "leadId",
      COALESCE(lead.name,'Unknown') AS "leadName",calls.salesperson_membership_id AS "salespersonId",
      COALESCE(users.display_name,'Unassigned') AS "salespersonName",COALESCE(lead.source,'unknown') AS campaign,
      calls.phone_normalized AS phone,UPPER(calls.direction) AS direction,calls.started_at AS "startedAt",
      calls.ended_at AS "endedAt",calls.duration_seconds AS "durationSeconds",
      calls.result='connected' AS connected,calls.result AS outcome,'connected_dashboard' AS source
      FROM callflow_call_events calls
      LEFT JOIN callflow_leads lead ON lead.id=calls.lead_id AND lead.tenant_id=calls.tenant_id
      LEFT JOIN callflow_memberships membership ON membership.id=calls.salesperson_membership_id AND membership.tenant_id=calls.tenant_id
      LEFT JOIN callflow_users users ON users.id=membership.user_id
      WHERE ${clauses.join(" AND ")} ORDER BY calls.started_at DESC,calls.id DESC LIMIT 50001`, values);
    if (result.rows.length > 50000) throw new Error("More than 50,000 calls match. Select a shorter date range or one salesperson.");
    return result.rows.map((row) => ({ ...row, leadId: row.leadId || row.phone,
      salespersonId: row.salespersonId || "", startedAt: new Date(row.startedAt).toISOString(),
      endedAt: row.endedAt ? new Date(row.endedAt).toISOString() : "" })) as CallFlowCallRecord[];
  });
}
